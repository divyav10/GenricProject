package com.GenericProj.genericProj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenericProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenericProjApplication.class, args);
	}

}

